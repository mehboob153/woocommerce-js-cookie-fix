﻿=== WooCommerce js cookie fixer upper ===

Contributors: Mahboob
Tags: js cookie, mod_security, hosting
Requires at least: 4.5.0
Tested up to: 4.7.4
Stable tag: 1.0
WC requires at least: 3.0
WC tested up to: 3.0.4
License: GPLv3 or later License
URI: http://www.gnu.org/licenses/gpl-3.0.html

Some hosting companies uses outdated mod_security rulesets which causes problems with some sites being able to load js.cookie.min.js file — this plugin resolves this by renaming the file being loaded.
 

== Description ==

Some hosting companies uses outdated mod_security rulesets which causes problems with some sites being able to load js.cookie.min.js file — this plugin resolves this by renaming the file being loaded.


== Installation ==

1. Download the plugin & install it to your `wp-content/plugins` folder (or use the Plugins menu through the WordPress Administration section)
2. Activate the plugin
3. Done!


== Changelog ==

= 1.0 = 
 * Initial Release